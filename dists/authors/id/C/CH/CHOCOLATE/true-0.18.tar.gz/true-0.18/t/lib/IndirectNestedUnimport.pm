package IndirectNestedUnimport;

use strict;
use warnings;

use Contemporary::Perl::Subclass::Subclass;
use Contemporary::Perl::Subclass::Subclass;

{
    no Contemporary::Perl::Subclass::Subclass;
    no Contemporary::Perl::Subclass::Subclass;
}
