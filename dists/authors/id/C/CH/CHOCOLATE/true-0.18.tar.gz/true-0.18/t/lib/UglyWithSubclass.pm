package UglyWithSubclass;

use strict;
use warnings;

use Contemporary::Perl::Subclass;

sub Ugly {
    use Contemporary::Perl::Subclass;
    # nested scope
    'UglyWithSubclass'
}

=pod

=head1 hello

=cut

0;

my $temp = 0;

0;

__END__

0
