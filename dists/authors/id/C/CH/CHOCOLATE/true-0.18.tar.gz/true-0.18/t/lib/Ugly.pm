package Ugly;

use strict;
use warnings;

use Contemporary::Perl;

sub Ugly {
    use Contemporary::Perl;
    # nested scope
    'Ugly'
}

=pod

=head1 hello

=cut

0;

my $temp = 0;

0;

__END__

0
