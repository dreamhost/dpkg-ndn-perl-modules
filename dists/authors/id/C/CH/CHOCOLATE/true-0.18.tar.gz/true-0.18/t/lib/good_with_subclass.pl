#!/usr/bin/env perl

use Contemporary::Perl::Subclass;

sub good_with_subclass { 'good_with_subclass' };
