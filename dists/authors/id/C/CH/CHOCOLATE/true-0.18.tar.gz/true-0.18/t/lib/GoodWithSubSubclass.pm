package GoodWithSubSubclass;

use strict;
use warnings;

use Contemporary::Perl::Subclass::Subclass;

sub Good { 'GoodWithSubSubclass' }
