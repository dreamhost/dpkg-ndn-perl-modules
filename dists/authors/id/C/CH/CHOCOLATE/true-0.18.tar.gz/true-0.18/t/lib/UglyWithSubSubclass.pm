package UglyWithSubSubclass;

use strict;
use warnings;

use Contemporary::Perl::Subclass::Subclass;

sub Ugly {
    use Contemporary::Perl::Subclass::Subclass;
    # nested scope
    'UglyWithSubSubclass'
}

=pod

=head1 hello

=cut

0;

my $temp = 0;

0;

__END__

0
