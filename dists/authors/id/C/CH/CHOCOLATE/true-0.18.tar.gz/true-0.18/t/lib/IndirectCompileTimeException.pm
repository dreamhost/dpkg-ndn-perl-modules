package IndirectCompileTimeException;

use strict;
use warnings;

use Contemporary::Perl::Subclass::Subclass;

BEGIN { die __PACKAGE __ }
