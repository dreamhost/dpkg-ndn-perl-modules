package DirectCompileTimeException;

use strict;
use warnings;

use true;

BEGIN { die __PACKAGE__ }
