package DirectTopLevelUnimport;

use strict;
use warnings;

use true;
use true;

no true;
no true; # test duplicate unimport
