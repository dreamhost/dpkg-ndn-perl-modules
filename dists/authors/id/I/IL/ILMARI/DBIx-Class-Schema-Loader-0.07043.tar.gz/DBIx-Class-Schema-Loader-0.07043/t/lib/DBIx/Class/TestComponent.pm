package DBIx::Class::TestComponent;

sub dbix_class_testcomponent { 'dbix_class_testcomponent works' }

1;
