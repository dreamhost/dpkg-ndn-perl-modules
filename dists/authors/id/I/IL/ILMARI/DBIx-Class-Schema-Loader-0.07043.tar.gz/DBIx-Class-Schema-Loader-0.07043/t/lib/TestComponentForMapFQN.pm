package TestComponentForMapFQN;

sub testcomponentformap_fqn { 'TestComponentForMapFQN works' }

1;
