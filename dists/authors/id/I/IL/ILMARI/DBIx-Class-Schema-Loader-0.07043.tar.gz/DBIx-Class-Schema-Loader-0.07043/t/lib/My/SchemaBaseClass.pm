package My::SchemaBaseClass;
use base 'DBIx::Class::Schema';
1;
