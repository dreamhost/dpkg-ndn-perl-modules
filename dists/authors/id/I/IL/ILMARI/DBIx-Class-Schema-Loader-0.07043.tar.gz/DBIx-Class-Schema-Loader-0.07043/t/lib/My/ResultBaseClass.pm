package My::ResultBaseClass;
use base 'DBIx::Class::Core';
1;
