# Copyrights 2001-2014 by [Mark Overmeer <perl@overmeer.net>].
#  For other contributors see Changes.
# See the manual pages for details on the licensing terms.
# Pod stripped from pm file by OODoc 2.01.

use warnings;
use strict;

package C::G::H;
our $VERSION = '0.19';

use base 'C::G';

sub c_g_h() {'c_g_h'}

1;
