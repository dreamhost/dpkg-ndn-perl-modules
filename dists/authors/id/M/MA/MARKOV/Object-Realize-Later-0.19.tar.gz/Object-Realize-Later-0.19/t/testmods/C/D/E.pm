# Copyrights 2001-2014 by [Mark Overmeer <perl@overmeer.net>].
#  For other contributors see Changes.
# See the manual pages for details on the licensing terms.
# Pod stripped from pm file by OODoc 2.01.

use warnings;
use strict;

package C::D::E;
our $VERSION = '0.19';

use base 'C::D';

sub c_d_e() {'c_d_e'}

1;
