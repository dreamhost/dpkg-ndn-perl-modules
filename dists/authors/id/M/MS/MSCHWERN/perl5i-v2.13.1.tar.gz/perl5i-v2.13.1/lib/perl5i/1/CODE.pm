package perl5i::1::CODE;

1;
