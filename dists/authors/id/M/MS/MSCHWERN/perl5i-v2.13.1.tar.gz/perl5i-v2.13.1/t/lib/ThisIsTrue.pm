package ThisIsTrue;

use perl5i::2;

sub bar { return 42 }
