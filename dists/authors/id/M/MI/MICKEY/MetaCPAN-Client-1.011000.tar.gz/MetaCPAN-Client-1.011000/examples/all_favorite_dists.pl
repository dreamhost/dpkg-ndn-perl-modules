use strict;
use warnings;

use MetaCPAN::Client;

# use raw ES filter on a { match_all => {} } query

# find 'latest' status releases with at least 700 failing tests
# which consist at least 50% of their overall number of tests.

my $release = MetaCPAN::Client->new->all(
    'favorites',
    {
        es_filter => {
            distribution => 'Moose'
        },
    }
);

use DDP;
p $release;
