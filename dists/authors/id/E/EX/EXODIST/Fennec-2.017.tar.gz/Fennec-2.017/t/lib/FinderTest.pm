package FinderTest;
use strict;
use warnings;

use Fennec;

tests something => sub {
    ok( 1, "generic test" );
};

done_testing;
