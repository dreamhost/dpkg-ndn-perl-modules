package InheritanceChild;
use strict;
use warnings;

use base 'InheritanceParent';

sub foo { 'foo' }

1;
