package InheritanceParent;
use strict;
use warnings;

use Exporter::Declare qw/default_export import/;

default_export the_export => sub {
    return 'the_export';
};

1;
