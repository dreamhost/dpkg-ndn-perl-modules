package Bar;
no circular::require;
use Bar2;
1;
