package Baz3;
use Baz2;
1;
