package Baz;
use Bar;
1;
