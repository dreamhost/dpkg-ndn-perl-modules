package Bar;
use Baz;
1;
