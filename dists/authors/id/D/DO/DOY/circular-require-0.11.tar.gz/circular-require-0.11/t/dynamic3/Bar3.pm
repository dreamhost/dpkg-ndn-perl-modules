package Bar3;
use Bar2;
1;
