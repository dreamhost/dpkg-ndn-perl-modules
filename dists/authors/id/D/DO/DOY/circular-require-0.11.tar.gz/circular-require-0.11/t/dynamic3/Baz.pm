package Baz;
use Baz2;
1;
