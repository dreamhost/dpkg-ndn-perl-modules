package Bar2;
use Bar3;
1;
