package Blorg;
use Bar;
1;
