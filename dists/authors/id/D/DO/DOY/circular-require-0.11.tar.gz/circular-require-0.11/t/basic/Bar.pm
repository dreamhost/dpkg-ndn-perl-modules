package Bar;
use Baz;
sub quux { }
1;
