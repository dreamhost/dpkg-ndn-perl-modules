package Quux;
use Bar;
1;
