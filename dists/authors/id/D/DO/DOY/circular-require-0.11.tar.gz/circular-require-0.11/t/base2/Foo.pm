package Foo;
use strict;
use warnings;

use base 'Bar';

sub foo { "foo" }

1;
