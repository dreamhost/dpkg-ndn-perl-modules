package Foo;
no circular::require;
use Bar;
1;
