package Bar;
use strict;
use warnings;

sub bar { "bar" }

1;
