package Foo;
use Bar;
1;
