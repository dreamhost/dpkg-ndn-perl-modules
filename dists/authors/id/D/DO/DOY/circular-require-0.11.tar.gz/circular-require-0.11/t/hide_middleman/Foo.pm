package Foo;
use strict;
use warnings;

use Bar;
1;
