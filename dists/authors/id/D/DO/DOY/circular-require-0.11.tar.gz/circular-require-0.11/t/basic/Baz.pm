package Baz;
require Foo;
require Bar;
1;
