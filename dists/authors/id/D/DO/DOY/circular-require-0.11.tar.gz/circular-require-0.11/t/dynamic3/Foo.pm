package Foo;
use Bar;
use Baz;
1;
