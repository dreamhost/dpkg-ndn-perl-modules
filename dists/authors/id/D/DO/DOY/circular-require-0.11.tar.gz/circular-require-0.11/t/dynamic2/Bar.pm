package Bar;
require Baz;
use circular::require;
require Quux;
1;
