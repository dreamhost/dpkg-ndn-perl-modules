package Baz;
use Quux;
1;
