package Bar;
use strict;
use warnings;

use base 'Foo';

1;
