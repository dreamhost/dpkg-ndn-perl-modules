package Foo;
use Baz;
sub quux { }
1;
