package Baz2;
use Baz3;
1;
