package Quux;
use Blorg;
1;
