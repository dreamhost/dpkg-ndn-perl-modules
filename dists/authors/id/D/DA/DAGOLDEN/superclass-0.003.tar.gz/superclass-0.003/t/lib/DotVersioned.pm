package DotVersioned;
our $VERSION = v1.0.0;

1;

