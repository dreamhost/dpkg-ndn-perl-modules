package Dummy::Outside;

sub exclaim { "I CAN FROM " . __PACKAGE__ }

1;

