package Search::Elasticsearch::Client::Direct;
$Search::Elasticsearch::Client::Direct::VERSION = '1.20';
use parent 'Search::Elasticsearch::Client::1_0::Direct';

warn <<'END';
The Search::Elasticsearch::Client::Direct class is deprecated.
Please specify the version of the API that you would like to use, eg:

     $e = Search::Elasticsearch->new(
         client => '1_0::Direct'        # default
     );

END

1;

=pod

=encoding UTF-8

=head1 NAME

Search::Elasticsearch::Client::Direct - Deprecated

=head1 VERSION

version 1.20

=head1 DESCRIPTION

This class has been deprecated.  Please see the
L<Search::Elasticsearch::Client::1_0::Direct> class instead.

=head1 AUTHOR

Clinton Gormley <drtech@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2015 by Elasticsearch BV.

This is free software, licensed under:

  The Apache License, Version 2.0, January 2004

=cut

__END__

# ABSTRACT: Deprecated


